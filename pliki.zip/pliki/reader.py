import sys
import csv

PATH_TO_FILES = "pliki_csv\\"


def chceck_file_name(file_name: str) -> str:
    if not file_name.endswith(".csv"):
        return file_name + ".csv"
    else:
        return file_name


def read_data_from_file(input_file: str) -> list[list[str]]:
    with open(f"{PATH_TO_FILES}{input_file}") as file:
        return list(csv.reader(file))


def change_data_in_our_matrix():
    for incoming_change in changes_in_file:
        change_data: list[str] = incoming_change.split(",")
        if len(change_data) == 3:
            x_value, y_value, end_value = change_data
            if x_value.isdigit() and y_value.isdigit():
                matrix[int(x_value)][int(y_value)] = end_value
            else:
                print(f"Podane kordynaty {x_value=:}, {y_value=:} są błędne!")
        else:
            print(
                f"Dane: {incoming_change} są niepropawne.",
                "Do zmiany danch potrzebne są tylko 3 wartości: x_value, y_value, end_value",
                sep="\n"
            )


def write_data_to_file(output_file: str):
    with open(f"{PATH_TO_FILES}{output_file}", mode="w") as file:
        writer = csv.writer(file)
        writer.writerows(matrix)


if __name__ == "__main__":
    input_file, output_file, *changes_in_file = sys.argv[1:]
    input_file = chceck_file_name(input_file)
    output_file = chceck_file_name(output_file)

    matrix = read_data_from_file(input_file)
    change_data_in_our_matrix()
    write_data_to_file(output_file)


